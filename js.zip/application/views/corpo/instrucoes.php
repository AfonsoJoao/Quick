<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/bootstrap4/bootstrap.min.css') ?>">
<html>
<body style="background-color:#FAFAFA;">
<br><br><br><br><br>
<div class="container">
  <div class="row">
<div class="card-deck">
  <div class="card border-primary">
    <img src="<?php echo base_url('application/images/email.PNG') ?>" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Acessar e-mail:</h5>
      <p class="card-text">Acesse o seu <b>e-mail</b> e procure pelo e-mail da nossa equipe com a sua nova senha (caso não encontre verifique a sua lixeira).</p>
    </div>
  </div>
  <div class="card border-primary">
    <img src="<?php echo base_url('application/images/copiar.PNG') ?>" class="card-img-top" alt="..." height="160px">
    <div class="card-body">
      <h5 class="card-title">Copiar senha:</h5>
      <p class="card-text">copie sua nova senha.</p>
    </div>
  </div>
  <div class="card border-primary">
    <img src="<?php echo base_url('application/images/login.PNG') ?>" class="card-img-top" alt="...">
    <div class="card-body">
    <br>
      <h5 class="card-title">Logar com a nova senha:</h5>
      <p class="card-text ">Acesse a sua conta usando o seu amail e sua nova senha temporária.</p>
    </div>
  </div>
  <div class="card border-primary">
    <img src="<?php echo base_url('application/images/Editar.PNG') ?>" class="card-img-top" alt="...">
    <div class="card-body">
    <br>
      <h5 class="card-title">Editar informações:</h5>
      <p class="card-text">Acesse a area de de editar conta e altere a sua senha para a senha desejada.</p>
    </div>
  </div>
  </div>
  </div>
</div>
<br>
  <br>
  <center><a class="btn btn-primary" href="<?php echo base_url('login/')?>">Voltar para a tela de login</a></center>
  <br>
  </body>
  </html>