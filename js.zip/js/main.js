$(document).ready(function(){
$("#imagemupload").uploadFile({
	url:"http://localhost/ProjetoQuick/cadastroprodutos/uploadImagem",
	fileName:"imagem"
	});
    });